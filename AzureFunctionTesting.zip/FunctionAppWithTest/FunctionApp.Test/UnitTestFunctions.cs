using FunctionAppWithTest;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FunctionApp.Test
{
    [TestClass]
    public class UnitTestFunctions
    {
        private readonly ILogger logger = TestFactory.CreateLogger();
        [TestMethod]
        public async Task Request_With_Value()
        {
            var request = TestFactory.CreateHttpRequest("name", "Gouri");
            var response = (OkObjectResult)await MyHttpTrigger.Run(request, logger);
            Assert.AreEqual("Hello, Gouri. This HTTP triggered function executed successfully.", response.Value);

        }
        [TestMethod]
        public async Task Request_Without_Value()
        {
            var request = TestFactory.CreateHttpRequest("name",null);
            var response = (OkObjectResult)await MyHttpTrigger.Run(request, logger);
            Assert.AreEqual("This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.", response.Value);
        }
        [TestMethod]
        public void Request_Timer()
        {
            var logger = (ListLogger)TestFactory.CreateLogger(LoggerTypes.List);
            MyTimerTrigger.Run(null, logger);
            var msg = logger.Logs[0];
            Console.WriteLine(msg);
            string actual = msg;
            string expected = "C# Timer trigger function executed at:";
            if (actual.Contains(expected))
            {
                Assert.AreEqual(true, true);
            }
            else
            {
                Assert.AreEqual(true, false);
            }
        }
    }
}
